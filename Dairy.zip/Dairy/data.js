{
    "dates"[
        {
            "date": "2022-07-21T00:00:00+01:00",
            "bookingSlots": [
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-21T13:00:00+01:00",
                    "toTime": "2022-07-21T14:00:00+01:00",
                    "quantity": 3,
                    "isPeak": false,
                    "checkInMinutes": 0
                },
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-21T14:00:00+01:00",
                    "toTime": "2022-07-21T15:00:00+01:00",
                    "quantity": 3,
                    "isPeak": false,
                    "checkInMinutes": 0
                },
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-21T15:00:00+01:00",
                    "toTime": "2022-07-21T16:00:00+01:00",
                    "quantity": 3,
                    "isPeak": false,
                    "checkInMinutes": 0
                },
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-21T16:00:00+01:00",
                    "toTime": "2022-07-21T17:00:00+01:00",
                    "quantity": 3,
                    "isPeak": false,
                    "checkInMinutes": 0
                },
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-21T17:00:00+01:00",
                    "toTime": "2022-07-21T18:00:00+01:00",
                    "quantity": 3,
                    "isPeak": false,
                    "checkInMinutes": 0
                },
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-21T18:00:00+01:00",
                    "toTime": "2022-07-21T19:00:00+01:00",
                    "quantity": 3,
                    "isPeak": true,
                    "checkInMinutes": 0
                },
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-21T19:00:00+01:00",
                    "toTime": "2022-07-21T20:00:00+01:00",
                    "quantity": 3,
                    "isPeak": true,
                    "checkInMinutes": 0
                },
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-21T20:00:00+01:00",
                    "toTime": "2022-07-21T21:00:00+01:00",
                    "quantity": 3,
                    "isPeak": true,
                    "checkInMinutes": 0
                }
            ]
        },
        {
            "date": "2022-07-22T00:00:00+01:00",
            "bookingSlots": [
                {
                    "id": 2,
                    "description": "Double Flight",
                    "fromTime": "2022-07-22T13:00:00+01:00",
                    "toTime": "2022-07-22T14:00:00+01:00",
                    "quantity": 3,
                    "isPeak": true,
                    "checkInMinutes": 0
                }
            ]
        }
    ]
}