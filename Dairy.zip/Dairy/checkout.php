
<?php  

/* Template Name: Checkout-Page */

?>


<?php 


if (isset($_POST['submit']))
{

  $dateandTime=$_POST['dateandTime'];
  $dateWIthtime=$_POST['dateWIthtime'];

  
  // echo $dateandTime;
  $selectedDates=$_POST['selectedDates'];
  $selectedQty=$_POST['selectedQty'];
  $selectdBookType=$_POST['selectdBookType'];
//   if ($selectdBookType ==1){
//     $selectdBookType ="Single Flight";
//   }
//   else if(selectdBookType == 2){
//     $selectdBookType ="Dobule Flight";
//   }
//   else{
//     $selectdBookType ="Private Flight";
//   }
//   echo $selectdBookType;


//   echo $selectedDates;

//   echo "           ";
//   echo $timerr;
}
else{
  // echo "sorry Invalid Sesssion !!!!";
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dairy</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_directory')?>/css/style.css">

</head>

<body>

    <header>
        <div class="container">
            <a href="#">Booking System Diary functions</a>
        </div>
    </header>
    <section class="checkout_page" id="basePage1122">
        <form class="contact_form" id="PayForm"   method="POST">
            <div class="container">
                <h2 class="mt-0 mb-2 mb-md-4 font-weight-bold">CHECKOUT</h2>
                <div class="booking_details">
                    <h3 class="mt-0 mb-2">YOUR BOOKING FOR <?php echo $_SESSION["selectedDates"];?> 2022-08-03T20:00:00+01:00 AT STOCKHOLM</h3>
                    <P class="mt-0 mb-2 mb-md-3">Check-in time: <?php echo $_SESSION["selectedDates"];?>2022-08-03T20:00:00+01:00</P>
                    <ul class="booking_details_inr">
                        <li class="booking_title">
                            <h3>2 FLIGHT PACKAGE - <span id="BookingType"><?php echo $_SESSION['selectdBookType'];?>2</span></h3>
                            <p><b>Location:</b> Stockholm</p>
                            
                        </li>
                        <li>
                            <p><b>Time: <span id="BookingDate"><?php echo $_SESSION['booDateTIME'];?>2022-08-03T20:00:00+01:00</span></b></p>
                        </li>
                        <li class="booking_user">
                            <p><b>1</b></p>
                        </li>
                        <li>
                            <p><b>Quantity: <span id="BookingQty" value="<?php echo $_SESSION['selectedQty'];?>">2<?php echo $_SESSION['selectedQty'];?></span></b></p>
                        </li>
                        <li>
                            <p><b>Price: <span value=""><?php echo $_SESSION['selectedQty'];?></span></b></p>
                        </li>
                    </ul>
                    <div class="time_remaining d-sm-flex justify-content-between align-items-center mt-3 mt-md-4 mb-1 mb-sm-2">
                        <p class="mb-2 mb-sm-0">Time remaining to complete this booking: <span id="demo">10:00</span> </p>
                        <h3 class="m-0">Total: 695.00Kr</h3>
                    </div>
                </div>
                <div class="payment_details">
                    <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">PLEASE ENTER YOUR BILLING AND PAYMENT DETAILS</h2>
                    <div class="row">
                        <div class="col-lg-6">
                            <h3 class="mt-0 mb-3">BILLING DETAILS</h3>
                            <div class="form-group">
                                <label>First name</label>
                                <input type="text" class="form-control" required name="username" id="fname">
                            </div>
                            <div class="form-group">
                                <label>LastName</label>
                                <input type="text" class="form-control" required name="LastName" id="lname">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" required name="email" id="email">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <form class="contact_checkbox" action="">
                                <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">I understand that I need to arrive
                                        by 16:45 in order to take part in my first activity</label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                        <label class="form-check-label" for="exampleCheck1">I have read and agree to the <a
                                            href="#">terms and conditions</a></label>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="text-right d-flex justify-content-between flex-wrap">
                            
                            <a class="btn_design back_btn btn mr-3" href="http://localhost/wordpress/event-2/">Back</a>
                            
                            <div class="custom-right-group-btn">
                                
                                <button type="submit" name="submit" class="btn_design btn" id="Payments">Pay Now</button>
                                
                                <button type="submit" class="btn_design btn book-now" id="BookNow">Book Now</button>
                            </div>
                            
                            
                            <!-- <a class="btn_design btn" name="submit" href="http://localhost/wordpress/ime/"></a> -->
                        </div>
                    </div>
                    
                </form>
</section> 
        <div class="container" id="PaymentDiv">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6 bg-light">                
                    <form  method="POST" class="payment-form">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email Address</label>
                            <input type="email" class="form-control"   name="email" id="payemail" aria-describedby="emailHelp" placeholder="Enter email">
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Name</label>
                            <input type="text" class="form-control username" name="name" id="payname"  placeholder="username" >
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Card Number</label>
                            <input type="text" class="form-control" name="card_number" id="cardNumber" placeholder="card number">
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Card Month</label>
                            <input type="text" class="form-control" name="card_exp_month" id="cardExp" placeholder="card exp month">
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Card Year</label>
                            <input type="text" class="form-control" name="card_exp_year" id="cardExpYear" placeholder="card exp year">
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Card Cvv </label>
                            <input type="text" class="form-control" name="card_cvc" id="cardCVC" placeholder="CVC">
                        </div>
                        
                        <button type="submit" class="btn_design btn" id="Payments">Submit</button>
                    </form>
                    
                    
                       
                </div>
                <div class="col-md-3"></div>
            </div>
            
            <div>
                <div id="response"></div>
            <button type="button" class="btn_design btn" id="payButton">payButton</button>

            </div>  
            <form action="" class="hidden" >
                <input type="hidden" id="bookingReference">
                <input type="hidden" id="expiryDate">
                <input type="hidden" id="saleTotal">
                <input type="hidden" id="salesOrderId">
                <input type="hidden" id="salesOrderItemId">
                <input type="hidden" id="sessionId">
            </form>
        </div>
        <button type="submit" class="btn_design btn"  name="submit" id="Complete">Complete Now</button>

    <footer>
        <div class="container">
            <p class="text-center">© Copyright 2022 Booking System Diary functions</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>


    <script src="<?php bloginfo('template_directory')?>/js/script.js"></script>

    





<script>
$(document).ready(function () {
    var retrievedUsername = localStorage.getItem('user_name'); //retrieve the key
    // alert(retrievedUsername);
    $("#PaymentDiv").hide();
    $("#Complete").hide();
    $("#payButton").hide();
    $("#BookNow").hide();
    BookNow();
    timers();
    $("#Complete").on('click',function (params) {
        completePay();
        
    })
       
function BookNow() {
        let bookingDat=$("#BookingDate").text();
        let BookingQt=$("#BookingQty").text();

        let BookingTypId =$("#BookingType").text();
        console.log(BookingTypId);
        
        // let sessionId= "335137f2-e362-4aa5-ad16-03b98206j02g";
        let sessionId ="335137f2-e362-4aa5-ad16-03b98200f07f";
        // let sessionId ="cef0cbf3-6458-4f13-a418-ee4d7e";

    let unitCost= 5;
    let url ='http://enginetest.megafun.no/bookings/create?bookingTypeId='+BookingTypId.trim()+'&quantity='
        +BookingQt+'&bookingDate='+bookingDat+'&sessionId='+sessionId+'&unitCost='+unitCost+'&discountCode='+null+'&vouchers='+null;
        console.log(url);   
        $.ajax({
          url:url,
          type:'POST',
            success: function(data, textStatus, xhr) {
                if (xhr.status == 200) {
                    $("#Payments").show();
                    $("#BookNow").hide();
                }
        console.log(xhr.status);
            // console.log(data);
            // $("#hello").html(data);
            $("#response").html(data);
            $("#bookingReference").val(data.bookingReference);
            $("#expiryDate").val(data.expiryDate);
            $("#saleTotal").val(data.saleTotal);
            $("#salesOrderId").val(data.salesOrderId);
            $("#salesOrderItemId").val(data.salesOrderItemId);
            $("#sessionId").val(data.sessionId);

            // console.log(data);
          }
        });
        
      } 
});
function timers() {
    const d = new Date();
    let countDownDate = d.getTime();
    var x = setInterval(function() {
        var x= new Date().getTime();
        // change for time diffrendce
        var now = x-1800000;
        
        // var now = x-18000;
        var distance = countDownDate - now;
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
        if (distance < 0) {
            clearInterval(x);
            window.location.href = "http://localhost/wordpress/event/";
            
            // document.getElementById("demo").innerHTML = "EXPIRED";
        }
    }, 1000);
}


</script>


<script>

    // $("#Complete").on('click',function (event) {
        function completePay() {
            // 335137f2-e362-4aa5-ad16-03b98200f87f
        
            event.preventDefault();
            let FirstName=$("#fname").val();
            let LastName=$("#lname").val();
            let email=$("#email").val();
            let street = "random";
            let town = "heu";
            let postcode="305923";
            let amount = 25;
            // let sessionId ="cef0cbf3-6458-4f13-a418-ee4d7e7505df";
            let sessionId =$("#sessionId").val();
            console.log(sessionId);

        
            // url2='http://enginetest.megafun.no/sales/complete?sessionId='+sessionId+'&firstName='+FirstName+'&lastName='+LastName+'&telephone='+null+
            // '&email='+email+'&street='+street+'&town='+town+'&postcode='+postcode+'&paymentAmount='+amount+'&vendorTaxCode='+null+'&vpsTxId='+null+'&txAuthNo='+null+'&status='+ null;
            // const url1 ='http://enginetest.megafun.no/sales/complete/?SessionId='+sessionId+'&FirstName='+FirstName+'&LastName='+LastName+'&Email='+email;
            // console.log(url1); 
            let url2 ="http://enginetest.megafun.no/sales/complete?sessionId=335137f2-e362-4aa5-ad16-03b98200f07f&firstName= Matt,&lastName= Development,&telephone= ,&email= matt@bookingsystem.com,&street= Random street,&town= Awesome town,&postcode= SH1 4BC,&paymentAmount= 25,&vendorTaxCode= ,&vpsTxId= ,&txAuthNo= ,&status=";
            console.log("url2===============>",url2);   
  
            $.ajax({
              type:'POST',
            url:url2,
              success:function (data, textStatus, xhr) {
                if (xhr.status == 200) {
                alert("booking compltered");
            }
         
                console.log(data);
              }
            });
        }
        //   }); 
        // } 
// });



$(document).on('click','#Payments',function (event) {
    event.preventDefault();

    let user_name = $("input[name=username]").val();
    let user_last_name = $("input[name=LastName]").val();
    let user_email = $("input[name=email]").val();
    $("#payemail").val(user_name);
    $("#payname").val(user_email);
//call validtate fucntion here 
    if(user_name && user_last_name && user_email){    
    $("#basePage1122").hide();
    $("#PaymentDiv").show();    
    
    let name = $(".username").val();
    console.log(name);
    $.ajax({
        type: "POST",
        url: "../sami/",
        data: {
            email:$("#payemail").val(),
            card_number:$("#cardNumber").val(),
            card_exp_month:$("#cardExp").val(),
            card_exp_year:$("#cardExpYear").val(),
            card_cvc:$("#cardCVC").val(),           
        },
        
        success: function(data, textStatus, xhr) {
            if (xhr.status == 200) {
                    $("#Complete").show();
            }
            console.log(textStatus);
            
            $("#response").html(data); 
        }
    });
}else{
        alert("Please fill all the data");
        return false;
    }

  function valid(){
    alert(323223);
    $("#PayForm").validate({
        errorClass: "error fail-alert", 
        validClass: "valid success-alert",
        rules: {
          username : {
            required: true,
            minlength: 3,
            maxlength: 15
          },
          LastName : {
            required: true,
            minlength: 3,
            maxlength: 15
          },
          email: {
            required: true,
            email: true
          },
        },
        messages : {
          username: {
            minlength: "Name should be at least 3 characters",
            maxlength: "Name should not be at greater than 15 characters"

          },

          LastName: {
           minlength: "Name should be at least 3 characters",
           maxlength: "Name should not be at greater than 15 characters"
         },
       email: {
        email: "The email should be in the format: abc@domain.tld"
      },
    }
  });

  }  
}); 
</script>   

</html>