var timerTime = $("#sessionVar").text();
timerTime =parseInt(timerTime/120);
//  var xy = 00+':22';
var timer2 = "00:25";
var interval =  (function() {


  var timer = timer2.split(':');
  //by parsing integer, I avoid all extra string processing
  var minutes = parseInt(timer[0], 10);
  var seconds = parseInt(timer[1], 10);
  --seconds;
  minutes = (seconds < 0) ? --minutes : minutes;
  if (minutes < 0) clearInterval(interval);
  seconds = (seconds < 0) ? 59 : seconds;
  seconds = (seconds < 10) ? '0' + seconds : seconds;
// alert(minutes);
  //minutes = (minutes < 10) ?  minutes : minutes;
  $('.countdown').html(minutes + ':' + seconds);
  timer2 = minutes + ':' + seconds;
  
}, 1000);
<div class="countdown"></div>



function timers() {
    $("#sessionVar").text()
    const d = new Date();
    let countDownDate = d.getTime();
    var x = setInterval(function() {
        var x= new Date().getTime();
        // change for time diffrendce
        var now = x-1800000;
        
        // var now = x-18000;
        var distance = countDownDate - now;
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
        if (distance < 0) {
            clearInterval(x);
            window.location.href = "http://localhost/wordpress/event/";
            
            // document.getElementById("demo").innerHTML = "EXPIRED";
        }
    }, 1000);
}


// function timers() {
//     var timerTime = $("#sessionVar").text();

//     const d = new Date();
//     let countDownDate = d.getTime();
//     var x = setInterval(function() {
//         var x= new Date().getTime();
//         // change for time diffrendce
//         var now = x-1800000;
//         // console.log("now2 =====>",now);
//         // var now = 1800-timerTime;
//         // console.log("now =====>",now);
//         // // var now = x-18000;
//         var distance = countDownDate - now;
//         var minutes = Math.floor(timerTime%60);
//         console.log("ggaf=====>>>>",minutes);
//         var seconds = Math.floor(59);
//         document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
//         if (distance < 0) {
//             clearInterval(x);
//             window.location.href = "http://localhost/wordpress/event/";
            
//             // document.getElementById("demo").innerHTML = "EXPIRED";
//         }
//     }, 1000);
// }
